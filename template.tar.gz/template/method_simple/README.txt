the directory should contain the following files:

1. training program ( for training from r^{obs}_{u,i} and predicting r_{u,i} )
2. augmenting program ( for tuning r_{u,i} as r'_{u,i} )
3. run.sh
4. Makefile
5. README.txt

experiment steps:
a. modify the data info in run.sh
b. modiry the training-program and augmenting-program info in run.sh
c. enter: sh run.sh

